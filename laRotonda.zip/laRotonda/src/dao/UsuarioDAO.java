package dao;

import model.Producto;
import model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    // Method para registar un usuario a la DB
    public void insertarUsuario (Usuario usuario) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "INSERT INTO usuarios (nombre, contrasena, rol) VALUES (?, ?, ?);";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, usuario.getNombre());
        ps.setString(2, usuario.getContrasena());
        ps.setInt(3, usuario.getRol());

        ps.executeUpdate();
        ps.close();
        connection.close();
    }

    // Method para eliminar usuarios
    public void eliminarUsuario(int id) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "DELETE FROM usuarios WHERE id = ?;";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, id);
        ps.executeUpdate();
        ps.close();
        connection.close();
    }

    // Method para listar usuarios
    public List<Usuario> listarUsuarios() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM usuarios;";
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            Usuario usuario = new Usuario(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("contrasena"),
                    rs.getInt("rol")
            );
            usuarios.add(usuario);
        }

        rs.close();
        st.close();
        connection.close();
        return usuarios;
    }

    // Method para cambiar rol
    public void cambiarRol(int idUsuario, int nuevoRol) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "UPDATE usuarios SET rol = ? WHERE id = ?;";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, nuevoRol);
        ps.setInt(2, idUsuario);
        ps.executeUpdate();
        ps.close();
        connection.close();
    }

    // Method para buscar usuario por nombre
    public Usuario buscarUsuario(String nombre, String contrasena) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM usuarios WHERE nombre = ? AND contrasena = ?;";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, nombre);
        ps.setString(2, contrasena);
        ResultSet rs = ps.executeQuery();

        Usuario usuario = null;
        if (rs.next()) {
            usuario = new Usuario(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("contrasena"),
                    rs.getInt("rol"));
        }
        rs.close();
        ps.close();
        connection.close();
        return usuario;
    }
}

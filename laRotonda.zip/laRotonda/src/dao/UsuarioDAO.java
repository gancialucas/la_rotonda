package dao;

import model.Producto;
import model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    // Method para registar un usuario a la DB
    public void insertarUsuario (Usuario usuario) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "INSERT INTO usuarios (nombre, contrasena, rol) VALUES (?, ?, ?);";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, usuario.getNombre());
        ps.setString(2, usuario.getContrasena());
        ps.setInt(3, usuario.getRol());

        ps.executeUpdate();
        ps.close();
        connection.close();
    }

    // Method para eliminar usuarios
    public void eliminarUsuario(int id) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "DELETE FROM usuarios WHERE id = ?;";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, id);
        ps.executeUpdate();
        ps.close();
        connection.close();
    }

    // Method para listar usuarios
    public List<Usuario> listarUsuarios() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM usuarios;";
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            Usuario usuario = new Usuario(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("contrasena"),
                    rs.getInt("rol")
            );
            usuarios.add(usuario);
        }

        rs.close();
        st.close();
        connection.close();
        return usuarios;
    }

    // Method para cambiar rol
    public void cambiarRol(int idUsuario, int nuevoRol) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "UPDATE usuarios SET rol = ? WHERE id = ?;";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, nuevoRol);
        ps.setInt(2, idUsuario);
        ps.executeUpdate();
        ps.close();
        connection.close();
    }

    // Method para buscar usuario por nombre
    public Usuario buscarUsuario(String nombre, String contrasena) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM usuarios WHERE nombre = ? AND contrasena = ?;";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, nombre);
        ps.setString(2, contrasena);
        ResultSet rs = ps.executeQuery();

        Usuario usuario = null;
        if (rs.next()) {
            usuario = new Usuario(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("contrasena"),
                    rs.getInt("rol"));
        }
        rs.close();
        ps.close();
        connection.close();
        return usuario;
    }

    // Method para validar credenciales
    public boolean validarCredenciales(String usuario, String password) {
        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM usuarios WHERE nombre=? AND contrasena=?")) {
            stmt.setString(1, usuario);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method para obtener rol de usuario
    public int obtenerRol(String usuario) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT rol FROM usuarios WHERE nombre=?")) {
            stmt.setString(1, usuario);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("rol");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0; // Rol por defecto si ocurre un error o no se encuentra el usuario
    }

    public Integer getIdUser(String usuarioNombre) throws SQLException {
        String sql = "SELECT id FROM usuarios WHERE nombre = ?";
        Integer userId = null;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, usuarioNombre);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    userId = rs.getInt("id");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el ID del usuario: " + e.getMessage());
            throw e; // O puedes lanzar una excepción personalizada si prefieres
        }

        return userId;
    }
}

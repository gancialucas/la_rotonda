package dao;

import model.Producto;
import model.Venta;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class VentaDAO {
    // Method para registar una venta
    public void registrarVenta(Venta venta) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "INSERT INTO ventas (id_usuario, total) VALUES (?, ?);";
        PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, venta.getIdUsuario());
        ps.setDouble(2, venta.getTotal());

        ps.executeUpdate();

        // Obtener id generado para la venta
        ResultSet rs = ps.getGeneratedKeys();
        if (rs.next()) {
            venta.setId(rs.getInt(1)); // Se le asigna el id a la venta
        }

        ps.close();
        connection.close();
    }

    // Method para listar historial de ventas
    public List<Venta> listarVentas () throws SQLException {
        List<Venta> ventas = new ArrayList<>();
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM ventas;";
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            Venta venta = new Venta(
                    rs.getInt("id"),
                    rs.getInt("id_usuario"),
                    rs.getDouble("total"),
                    rs.getDate("created_at")
            );
            ventas.add(venta);
        }

        st.close();
        rs.close();
        connection.close();
        return ventas;
    }

    // Method asociar productos a una venta
    public void registrarProductosEnVenta(int idVenta, Map<Producto, Integer> productosVendidos) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "INSERT INTO venta_productos (id_venta, id_producto, cantidad) VALUES (?, ?, ?)";
        PreparedStatement ps = connection.prepareStatement(sql);

        for (Map.Entry<Producto, Integer> entry : productosVendidos.entrySet()) {
            Producto producto = entry.getKey();
            int cantidad = entry.getValue();

            ps.setInt(1, idVenta);
            ps.setInt(2, producto.getId());
            ps.setInt(3, cantidad);  // Asumiendo que se vende 1 unidad de cada producto
            ps.executeUpdate();

            // Actualizar stock de productos
            ProductoDAO productoDAO = new ProductoDAO();
            productoDAO.actualizarStock(producto, cantidad);
        }

        ps.close();
        connection.close();
    }

    public void mostrarDetallesVenta(int idVenta) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT p.nombre, vp.cantidad, p.precio FROM venta_productos vp JOIN productos p ON vp.id_producto = p.id WHERE vp.id_venta = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, idVenta);
        ResultSet rs = ps.executeQuery();

        System.out.println("- Productos vendidos en la venta:");
        while (rs.next()) {
            String nombre = rs.getString("nombre");
            int cantidad = rs.getInt("cantidad");
            double precio = rs.getDouble("precio");

            System.out.println("   -> Producto: " + nombre + " | Cantidad: " + cantidad + " | Precio unitario: " + precio + " | Subtotal: " + (cantidad * precio));
        }

        rs.close();
        ps.close();
        connection.close();
    }
}

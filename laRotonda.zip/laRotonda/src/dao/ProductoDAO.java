package dao;

import model.Producto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    // Method para insertar un producto a la DB
    public void insertarProducto(Producto producto) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "INSERT INTO productos (nombre, stock, precio) VALUES (?, ?, ?);";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, producto.getNombre());
        ps.setInt(2, producto.getStock());
        ps.setDouble(3, producto.getPrecio());
        ps.executeUpdate();
        ps.close();
        connection.close();
    }

    // Method para eliminar producto
    public void eliminarProducto(int id) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "DELETE FROM productos WHERE id = ?;";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, id);
        ps.executeUpdate();
        ps.close();
        connection.close();
    }

    // Method para listar productos desde la DB
    public List<Producto> listarProductos() throws SQLException {
        List<Producto> productos = new ArrayList<>();
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM productos;";
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            Producto producto = new Producto(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"));
            productos.add(producto); // Añadimos el producto de la DB a la lista "productos"
        }
        rs.close();
        st.close();
        connection.close();
        return productos;
    }

    // Method para buscar producto por nombre
    public Producto buscarProducto(String nombre) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM productos WHERE nombre = ?;";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, nombre);
        ResultSet rs = ps.executeQuery();

        Producto producto = null;
        if (rs.next()) {
            producto = new Producto(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"));
        }
        rs.close();
        ps.close();
        connection.close();
        return producto;
    }

    public Producto buscarProductoPorId(int idProducto) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM productos WHERE id = ?;";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, idProducto);
        ResultSet rs = ps.executeQuery();

        Producto producto = null;
        if (rs.next()) {
            producto = new Producto(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"));
        }
        rs.close();
        ps.close();
        connection.close();
        return producto;
    }

    public void actualizarStock(Producto producto, int cantidadVendida) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "UPDATE productos SET stock = stock - ? WHERE id = ?;";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, cantidadVendida);
        ps.setInt(2, producto.getId());
        ps.executeUpdate();
        ps.close();
        connection.close();
    }
}
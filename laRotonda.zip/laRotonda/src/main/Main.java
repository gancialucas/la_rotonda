package main;

import dao.ProductoDAO;
import dao.UsuarioDAO;
import dao.VentaDAO;
import model.Producto;
import model.Usuario;
import model.Venta;

import java.sql.SQLException;
import java.util.*;

public class Main {
    public static void main(String[] args) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO usuarioDAO = new UsuarioDAO();

        int opcion;

        System.out.println("*************************************");
        System.out.println(" BIENVENIDO AL SISTEMA DE LA ROTONDA");
        System.out.println("*************************************");
        System.out.println("1. Iniciar Sesión");
        System.out.println("2. Registrarse");
        System.out.println("_____________________________________");
        System.out.print("-> Ingrese una opcion: ");
        opcion = scanner.nextInt();

        // Agregamos logica para iniciar sesión
        if (opcion == 1) {
            iniciarSesion(scanner, usuarioDAO);
        } else if (opcion == 2) {
            registrarse(scanner, usuarioDAO);
        } else {
            System.out.println("❌ Opción no valida, intente nuevamente\n");
        }
        scanner.close();
    }

    // Method Iniciar Sesión
    public static void iniciarSesion(Scanner scanner, UsuarioDAO usuarioDAO) {
        System.out.print("   - Usuario: ");
        scanner.nextLine();
        String nombreUsuario = scanner.nextLine();
        System.out.print("   - Contraseña: ");
        String password = scanner.nextLine();

        try {
            Usuario usuario = usuarioDAO.buscarUsuario(nombreUsuario, password);
            if (usuario != null) {
                System.out.println("\n✅ BIENVENIDO ..."); // Separador
                menu(scanner, usuario);
            } else {
                System.out.println("❌ Usuario o Contraseña incorrectos, intente nuevamente");
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar el usuario: " + nombreUsuario + ", " + e.getMessage() + "\n");
        }
    }

    // Method para Registrar Usuarios
    public static void registrarse(Scanner scanner, UsuarioDAO usuarioDAO) {
        System.out.print("   - Usuario: ");
        scanner.nextLine();
        String nombreUsuario = scanner.nextLine();
        System.out.print("   - Contraseña: ");
        String password = scanner.nextLine();

        Usuario usuario = new Usuario(0, nombreUsuario, password, 0);
        try {
            usuarioDAO.insertarUsuario(usuario);
            System.out.println("\n✅ ¡Usuario registrado correctamente!\n");
            menu(scanner, usuario);
        } catch (SQLException e) {
            System.out.println("❌ Error al registrar el usuario: " + e.getMessage() + "\n");
        }
    }

    // Method para mostar Menu
    public static void menu(Scanner scanner, Usuario usuario) {
        int opcion;
        ProductoDAO productoDAO = new ProductoDAO();
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        VentaDAO ventaDAO = new VentaDAO();

        // Mostar el rol del usuario
        String tipoUsuario = usuario.getRol() == 1 ? "Administrador" : "Empleado";
        System.out.println("   -> Acceso concedido como: " + tipoUsuario + "\n");

        String respuesta;
        do {
            System.out.println("*************************************");
            System.out.println("   MENÚ PRINCIPAL - La Rotonda");
            System.out.println("*************************************");
            System.out.println("1. Lista de productos.");
            System.out.println("2. Buscar producto por Nombre.");

            if (usuario.getRol() == 1) {
                System.out.println("3. Agregar producto.");
                System.out.println("4. Eliminar producto.");
                System.out.println("5. Lista de Usuarios.");
                System.out.println("6. Cambiar Rol a Usuarios.");
                System.out.println("7. Eliminar Usuario.");
            }

            System.out.println("8. Registrar Venta.");
            System.out.println("9. Historial de ventas.");
            System.out.println("_____________________________________");
            System.out.print("-> Ingrese una opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    listarProductos(scanner, productoDAO);
                    break;
                case 2:
                    buscarProductoPorNombre(scanner, productoDAO);
                    break;
                case 3:
                    if (usuario.getRol() == 1) {
                        agregarProducto(scanner, productoDAO);
                    } else {
                        System.out.println("❌ No tiene permisos para acceder a esta opción.");
                    }
                    break;
                case 4:
                    if (usuario.getRol() == 1) {
                        eliminarProducto(scanner, productoDAO);
                    } else {
                        System.out.println("❌ No tiene permisos para acceder a esta opción.");
                    }
                    break;
                case 5:
                    if (usuario.getRol() == 1) {
                        listarUsuarios();
                    } else {
                        System.out.println("❌ No tiene permisos para acceder a esta opción.");
                    }
                    break;
                case 6:
                    if (usuario.getRol() == 1) {
                        cambiarRolUsuarios(scanner, usuarioDAO);
                    } else {
                        System.out.println("❌ No tiene permisos para acceder a esta opción.");
                    }
                    break;
                case 7:
                    if (usuario.getRol() == 1) {
                        eliminarUsuarios(scanner, usuarioDAO);
                    } else {
                        System.out.println("❌ No tiene permisos para acceder a esta opción.");
                    }
                    break;
                case 8:
                    registrarVenta(scanner, productoDAO, ventaDAO, usuario);
                    break;
                case 9:
                    verHistorialVentas(ventaDAO);
                    break;
                case 99:
                    System.out.println("Saliendo ... ");
                    break;
                default:
                    System.out.println("❌ Opción no valida, intente nuevamente\n");
            }
        System.out.println("_____________________________________");
        System.out.print("-> Desea salir (Y/N): ");
        System.out.println("_____________________________________\n");
        respuesta = scanner.next();
        } while (respuesta.equalsIgnoreCase("N"));
    }

    // Method para agregar nuevos productos
    public static void agregarProducto(Scanner scanner, ProductoDAO productoDAO) {
        System.out.println("\n*************************************");
        System.out.println("       AGREGAR NUEVO PRODUCTO");
        System.out.println("*************************************");
        System.out.print("- Ingrese el nombre del producto: ");
        scanner.nextLine(); // Limpiar el buffer
        String nombreProducto = scanner.nextLine();

        System.out.print("- Ingrese el precio del producto: ");
        double precio = scanner.nextDouble();

        System.out.print("- Ingrese el stock del producto: ");
        int stock = scanner.nextInt();

        Producto producto = new Producto(0, nombreProducto, precio, stock);

        System.out.println("\n*** Agregando producto, espere ... ***\n");

        try {
            productoDAO.insertarProducto(producto);
            System.out.println("✅ ¡Producto agregado correctamente!\n");
        } catch (SQLException e) {
            System.out.println("❌ Error al agregar el producto: " + e.getMessage() + "\n");
        }
    }

    // Method para listar productos de la tienda desde la DB
    public static void listarProductos(Scanner scanner, ProductoDAO productoDAO) {
        try {
            System.out.println("\n*************************************");
            System.out.println("         LISTA DE PRODUCTOS");
            System.out.println("*************************************");

            List<Producto> productos = productoDAO.listarProductos();

            if (productos.isEmpty()) {
                System.out.println("❌ NO HAY PRODUCTOS REGISTRADOS");
            } else {
                for (Producto prod : productos) {
                    prod.mostrarInfo();
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al listar productos: " + e.getMessage() + "\n");
        }
        System.out.println("");
    }

    // Method para buscar producto por nombre
    public static void buscarProductoPorNombre(Scanner scanner, ProductoDAO productoDAO) {
        System.out.println("\n*************************************");
        System.out.println("     BUSCAR PRODUCTO POR NOMBRE");
        System.out.println("*************************************");
        System.out.print("- Ingrese el nombre del producto que desea buscar: ");

        scanner.nextLine(); // Limpiar el buffer
        String nombreDelProducto = scanner.nextLine();

        try {
            Producto productoBuscado = productoDAO.buscarProducto(nombreDelProducto);
            if (productoBuscado != null) {
                productoBuscado.mostrarInfo();
            } else {
                System.out.println("❌ PRODUCTO NO ENCONTRADO");
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar el producto: " + e.getMessage() + "\n");
        }
        System.out.println("");
    }

    // Method para eliminar producto por id
    public static void eliminarProducto(Scanner scanner, ProductoDAO productoDAO) {
        System.out.println("\n*************************************");
        System.out.println("       ELIMINAR PRODUCTO");
        System.out.println("*************************************");
        System.out.print("- Ingrese el id del producto que desea eliminar: ");
        int idProducto = scanner.nextInt();

        System.out.println("\n*** Eliminando producto, espere ***\n");

        try {
            productoDAO.eliminarProducto(idProducto);
            System.out.println("✅ ¡Producto eliminado correctamente!");
        } catch (SQLException e) {
            System.out.println("❌ Error al eliminar el producto: " + e.getMessage() + "\n");
        }
    }

    // Method para listar usuarios
    public static void listarUsuarios() {
        try {
            System.out.println("\n*************************************");
            System.out.println("         LISTA DE USUARIOS");
            System.out.println("*************************************");

            List<Usuario> usuarios = new UsuarioDAO().listarUsuarios();

            if (usuarios.isEmpty()) {
                System.out.println("❌ NO HAY USUARIOS REGISTRADOS EN EL SISTEMA ...");
            } else {
                for (Usuario usuario : usuarios) {
                    usuario.mostrarInfo(usuario, usuario.getRol());
                }
            }
            System.out.println("");
        } catch (SQLException e) {
            System.out.println("❌ Error al listar usuarios: " + e.getMessage() + "\n");
        }
    }

    // Method cambiar rol de usuario
    public static void cambiarRolUsuarios(Scanner scanner, UsuarioDAO usuarioDAO) {
        System.out.println("\n*************************************");
        System.out.println("       CAMBIAR ROL DE USUARIO");
        System.out.println("*************************************");

        System.out.print("   - Ingrese el ID del usuario curo rol desea cambiar: ");
        int idUsuario = scanner.nextInt();

        System.out.print("   - Ingrese el nuevo rol (1 para Administrador, 0 para Empleado): ");
        int nuevoRol = scanner.nextInt();

        System.out.println("\n*** Cambiando rol del usuario, espere ... ***\n");

        try{
            usuarioDAO.cambiarRol(idUsuario, nuevoRol);
            System.out.println("✅ ¡Rol cambiado correctamente!\n");
        } catch (SQLException e) {
            System.out.println("❌ Error al cambiar el rol del usuario: " + e.getMessage() + "\n");
        }
    }

    // Method eliminar usuario
    public static void eliminarUsuarios(Scanner scanner, UsuarioDAO usuarioDAO) {
        System.out.println("\n*************************************");
        System.out.println("          ELIMINAR USUARIO");
        System.out.println("*************************************");
        System.out.print("   - Ingrese el ID del usuario que desea eliminar: ");
        int idUsuario = scanner.nextInt();

        System.out.println("\n*** Eliminando usuario, espere ... ***\n");

        try {
            usuarioDAO.eliminarUsuario(idUsuario);
            System.out.println("✅ ¡Usuario eliminado correctamente!\n");
        } catch (SQLException e) {
            System.out.println("❌ Error al eliminiar el usuario: " + e.getMessage() + "\n");
        }
    }

    // Method para registrar una venta
    public static void registrarVenta(Scanner scanner, ProductoDAO productoDAO, VentaDAO ventaDAO, Usuario usuario) {
        Map<Producto, Integer> productosVendidos = new HashMap<>();
        double precioTotal = 0;

        System.out.println("\n*************************************");
        System.out.println("          REGISTRAR VENTA");
        System.out.println("*************************************");

        try{
            List<Producto> productosDisponibles = productoDAO.listarProductos();
            if (productosDisponibles.isEmpty()) {
                System.out.println("❌ NO HAY PRODUCTOS DISPONIBLES PARA VENDER");
                return;
            }

            System.out.println("- Ingrese el id de los productos a vender (ingrese 0 para finalizar)");
            for (Producto producto : productosDisponibles) {
                System.out.println("   ID: " + producto.getId() + " | " + producto.getNombre() + "| Precio: "+ producto.getPrecio() + " | Stock: " + producto.getStock());
            }

            int idProducto;
            do{
                System.out.print("   -> ID del producto: ");
                idProducto = scanner.nextInt();
                if (idProducto != 0) {
                    Producto producto = productoDAO.buscarProductoPorId(idProducto);
                    if (producto != null) {
                        System.out.print("      -> Cantidad: ");
                        int cantidad = scanner.nextInt();

                        // Validar si hay stock
                        if(producto.getStock() >= cantidad) {
                            // Verificar si el producto ya está registrado en la venta
                            if (productosVendidos.containsKey(producto)) {
                                productosVendidos.put(producto, productosVendidos.get(producto) + cantidad);
                            } else {
                                productosVendidos.put(producto, cantidad);
                            }

                            precioTotal += producto.getPrecio() * cantidad;
                            System.out.println("      ... Producto agregado correctamente ✅");
                        } else {
                            System.out.println("      ❌ Stock insuficiente para el producto: " + producto.getNombre() + " | Stock disponible: " + producto.getStock());
                        }
                    } else {
                        System.out.println("      ... Producto no encontrado, intente nuevamente ❌");
                    }
                }
            } while (idProducto != 0);

            // Registrar la venta
            if (!productosVendidos.isEmpty()) {
                Venta venta = new Venta(0, usuario.getId(), precioTotal, new java.util.Date());
                ventaDAO.registrarVenta(venta);

                // Registrar productos vendidos
                ventaDAO.registrarProductosEnVenta(venta.getId(), productosVendidos);
                System.out.println("\n✅ ¡VENTA REGISTRADA CORRECTAMENTE!\n   - Total: $" + precioTotal + "\n");
            } else {
                System.out.println("❌ No se registraron productos en la venta.");
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al registrar la venta: " + e.getMessage() + "\n");
        }
    }

    // Ver historial de venta
    public static void verHistorialVentas(VentaDAO ventaDAO) {
        try {
            List<Venta> ventas = ventaDAO.listarVentas();
            if (ventas.isEmpty()) {
                System.out.println("❌ No hay ventas registradas.");
            } else {
                System.out.println("\n*************************************");
                System.out.println("        HISTORIAL DE VENTAS");
                System.out.println("*************************************");

                for (Venta venta : ventas) {
                    System.out.println("ID: " + venta.getId() + " | Total: $" + venta.getTotal() + " | Fecha: " + venta.getCreated_at());
                    ventaDAO.mostrarDetallesVenta(venta.getId());
                    System.out.println("");
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al ver el historial de ventas: " + e.getMessage());
        }
    }
}

package gui;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class EmpleadoFrame extends JFrame {
    private JButton btnListaProductos, btnBuscarProducto, btnRegistrarVenta, btnCerrarSesion;

    public EmpleadoFrame(int userId) {
        setTitle("Dashboard - La Rotonda");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);

        // Título del Dashboard para Empleado
        JLabel lblTitulo = new JLabel("Dashboard | Empleado");
        EstilosGUI.configurarTitulo(lblTitulo);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);

        btnListaProductos = new JButton("Ver Lista de Productos");
        btnBuscarProducto = new JButton("Buscar Producto por Nombre");
        btnRegistrarVenta = new JButton("Nueva Venta");
        btnCerrarSesion = new JButton("Cerrar Sesión");

        EstilosGUI.configurarBotonEmpleado(btnListaProductos);
        EstilosGUI.configurarBotonEmpleado(btnBuscarProducto);
        EstilosGUI.configurarBotonEmpleado(btnRegistrarVenta);
        EstilosGUI.cerrarSesión(btnCerrarSesion);

        setLayout(new BorderLayout());
        add(lblTitulo, BorderLayout.NORTH); // Añade el título en la parte superior

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(btnListaProductos, gbc);

        gbc.gridy = 1;
        panel.add(btnBuscarProducto, gbc);

        gbc.gridy = 2;
        panel.add(btnRegistrarVenta, gbc);

        gbc.gridy = 3;
        panel.add(btnCerrarSesion, gbc);

        add(panel, BorderLayout.CENTER);

        // Configurar acciones de los botones
        btnCerrarSesion.addActionListener(e -> cerrarSesion());
        btnListaProductos.addActionListener(e -> abrirListaProductos());
        btnBuscarProducto.addActionListener(e -> abrirBuscarProducto());
        btnRegistrarVenta.addActionListener(e -> {
            try {
                abrirRegistrarVenta(userId);
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al abrir registro de venta", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void cerrarSesion() {
        new LoginFrame().setVisible(true);
        dispose();
    }

    private void abrirListaProductos() {
        new ListaProductosFrame().setVisible(true);
    }

    private void abrirBuscarProducto() {
        new BuscarProductoFrame().setVisible(true);
    }

    private void abrirRegistrarVenta(int userId) throws SQLException {
        new RegistrarVentaFrame(userId).setVisible(true);
    }
}
package gui;

import dao.UsuarioDAO;
import model.Usuario;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class RegistroFrame extends JFrame {
    private JTextField txtNuevoUsuario;
    private JPasswordField txtNuevaPassword;
    private JButton btnRegistrar, btnVolver;

    public RegistroFrame() {
        setTitle("Registro de Usuario - La Rotonda");
        setSize(425, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Configuración del panel principal
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 5, 10);

        // Título
        JLabel lblTitulo = new JLabel("Registro de Usuario");
        EstilosGUI.configurarTitulo(lblTitulo);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(lblTitulo, gbc);

        // Nombre del Usuario
        JLabel lblNuevoUsuario = new JLabel("Nombre del Usuario:");
        txtNuevoUsuario = new JTextField();
        EstilosGUI.configurarCampoTexto(txtNuevoUsuario);
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(lblNuevoUsuario, gbc);

        gbc.gridx = 1;
        panel.add(txtNuevoUsuario, gbc);

        // Contraseña
        JLabel lblNuevaPassword = new JLabel("Contraseña:");
        txtNuevaPassword = new JPasswordField();
        EstilosGUI.configurarCampoTexto(txtNuevaPassword);
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(lblNuevaPassword, gbc);

        gbc.gridx = 1;
        panel.add(txtNuevaPassword, gbc);

        // Botón de Registrar
        btnRegistrar = new JButton("Registrar");
        EstilosGUI.configurarBoton(btnRegistrar);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(btnRegistrar, gbc);

        // Botón Volver a Inicio de Sesión
        btnVolver = new JButton("Volver");
        EstilosGUI.configurarBoton(btnVolver);
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(btnVolver, gbc);

        add(panel);

        // Acción del botón Registrar
        btnRegistrar.addActionListener(e -> {
            String nuevoUsuario = txtNuevoUsuario.getText();
            String nuevaPassword = new String(txtNuevaPassword.getPassword());
            if (nuevoUsuario.isEmpty() || nuevaPassword.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos", "Error", JOptionPane.WARNING_MESSAGE);
            } else {
                registrarUsuario(nuevoUsuario, nuevaPassword);
            }
        });

        // Acción del botón Volver
        btnVolver.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });
    }

    private void registrarUsuario(String usuario, String password) {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        try {
            usuarioDAO.insertarUsuario(new Usuario(0, usuario, password, 0)); // El rol 0 es para empleado por defecto
            JOptionPane.showMessageDialog(this, "Usuario registrado exitosamente");
            new LoginFrame().setVisible(true);
            dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al registrar el usuario: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
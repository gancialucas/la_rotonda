package gui;

import dao.ProductoDAO;
import dao.VentaDAO;
import model.Producto;
import model.Venta;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegistrarVentaFrame extends JFrame {
    private JComboBox<String> productoComboBox;
    private JTextField cantidadField;
    private JButton agregarProductoButton, registrarVentaButton;
    private JTextArea carritoTextArea;
    private JLabel totalLabel;
    private JComboBox<String> estadoVentaComboBox;  // ComboBox para el estado de la venta

    private Map<Producto, Integer> productosVendidos = new HashMap<>();
    private double precioTotal = 0;

    public RegistrarVentaFrame(int userId) {
        setTitle("Nueva Venta - La Rotonda");
        getContentPane().setBackground(Color.LIGHT_GRAY); // Fondo neutro
        setSize(600, 600); // Ajustar tamaño para dar espacio extra
        setLocationRelativeTo(null);

        // Panel para selección de productos y cantidad
        JPanel productoPanel = new JPanel(new GridLayout(4, 2));
        productoComboBox = new JComboBox<>();
        cargarProductos();  // Cargar productos en el combo box

        productoPanel.add(new JLabel("Producto:"));
        EstilosGUI.configurarCampoTexto((JTextField) productoComboBox.getEditor().getEditorComponent());  // Si es editable

        productoPanel.add(productoComboBox);

        productoPanel.add(new JLabel("Cantidad:"));
        cantidadField = new JTextField();
        EstilosGUI.configurarCampoTexto(cantidadField);
        productoPanel.add(cantidadField);

        agregarProductoButton = new JButton("Agregar al Carrito");
        EstilosGUI.configurarBoton(agregarProductoButton);
        productoPanel.add(agregarProductoButton);

        // ComboBox para seleccionar el estado de la venta
        estadoVentaComboBox = new JComboBox<>(new String[] { "Pago", "Pendiente", "No abonó" });
        EstilosGUI.configurarCampoTexto((JTextField) estadoVentaComboBox.getEditor().getEditorComponent());  // Si es editable
        productoPanel.add(estadoVentaComboBox);

        // Carrito y total
        carritoTextArea = new JTextArea(10, 30);
        EstilosGUI.configurarTextArea(carritoTextArea);  // Crear un méthodo para TextArea si necesitas estilo específico

        totalLabel = new JLabel("Total: $0.0");
        EstilosGUI.configurarTotal(totalLabel);  // Puedes ajustar este méthodo en 'EstilosGUI' para el total

        // Botón de registrar venta
        registrarVentaButton = new JButton("Registrar Venta");
        EstilosGUI.configurarBotonVenta(registrarVentaButton);

        // Agregar componentes al frame
        add(productoPanel, BorderLayout.NORTH);
        add(new JScrollPane(carritoTextArea), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(totalLabel, BorderLayout.WEST);
        bottomPanel.add(registrarVentaButton, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);

        // Estilos
        EstilosGUI.configurarComboBox(productoComboBox);
        EstilosGUI.configurarComboBox(estadoVentaComboBox);
        EstilosGUI.configurarTextArea(carritoTextArea);

        // Acciones
        agregarProductoButton.addActionListener(e -> {
            try {
                agregarProductoAlCarrito();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });
        registrarVentaButton.addActionListener(e -> registrarVenta(userId));

        setVisible(true);
    }

    private void cargarProductos() {
        try {
            ProductoDAO productos = new ProductoDAO();
            List<Producto> listarProductos = productos.listarProductos();
            for (Producto producto : listarProductos) {
                String nombreProducto = producto.getNombre();
                productoComboBox.addItem(nombreProducto);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar productos: " + e.getMessage());
        }
    }

    private void agregarProductoAlCarrito() throws SQLException {
        ProductoDAO productoDAO = new ProductoDAO();
        String productoComboBoxSelectedItem = (String) productoComboBox.getSelectedItem();
        Producto productoSeleccionado = productoDAO.buscarProducto(productoComboBoxSelectedItem);
        int cantidad = Integer.parseInt(cantidadField.getText());

        if (productoSeleccionado != null && cantidad > 0) {
            try {
                // Verificar stock disponible
                if (productoSeleccionado.getStock() >= cantidad) {
                    productosVendidos.merge(productoSeleccionado, cantidad, Integer::sum);
                    precioTotal += productoSeleccionado.getPrecio() * cantidad;

                    carritoTextArea.append("Producto: " + productoSeleccionado.getNombre() +
                            " | Cantidad: " + cantidad +
                            " | Subtotal: $" + (productoSeleccionado.getPrecio() * cantidad) + "\n");

                    totalLabel.setText("Total: $" + precioTotal);
                } else {
                    JOptionPane.showMessageDialog(this, "Stock insuficiente para " + productoSeleccionado.getNombre());
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    }

    private void registrarVenta(int userId) {
        VentaDAO ventaDAO = new VentaDAO();
        if (productosVendidos.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No se han agregado productos a la venta.");
            return;
        }

        try {
            // Obtener el estado seleccionado
            String estadoVenta = (String) estadoVentaComboBox.getSelectedItem();

            // Registrar venta en la base de datos
            Venta venta = new Venta(0, userId, precioTotal, estadoVenta, new Date());
            ventaDAO.registrarVenta(venta);

            // Registrar productos en la venta
            ventaDAO.registrarProductosEnVenta(venta.getId(), productosVendidos);

            JOptionPane.showMessageDialog(this, "Venta registrada exitosamente.\nTotal: $" + precioTotal +
                    "\nEstado: " + estadoVenta);

            // Resetear el formulario
            productosVendidos.clear();
            precioTotal = 0;
            carritoTextArea.setText("");
            totalLabel.setText("Total: $0.0");
            estadoVentaComboBox.setSelectedIndex(0);  // Reiniciar el estado al valor predeterminado
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al registrar la venta: " + e.getMessage());
        }
    }
}
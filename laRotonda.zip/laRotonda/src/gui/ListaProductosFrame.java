package gui;

import dao.ProductoDAO;
import model.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class ListaProductosFrame extends JFrame {
    private JTable tablaProductos;

    public ListaProductosFrame() {
        setTitle("Lista de Productos - La Rotonda");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Configuración del panel principal
        JPanel panel = new JPanel(new BorderLayout());

        // Título
        JLabel lblTitulo = new JLabel("Lista de Productos");
        EstilosGUI.configurarTitulo(lblTitulo);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(lblTitulo, BorderLayout.NORTH);

        // Configuración de la tabla
        tablaProductos = new JTable();
        cargarProductosEnTabla();
        tablaProductos.setFont(new Font("Arial", Font.PLAIN, 14));
        tablaProductos.setRowHeight(30);
        tablaProductos.setGridColor(Color.BLACK);
        tablaProductos.setShowGrid(true);

        // Configuración del encabezado de la tabla
        JTableHeader header = tablaProductos.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 16));
        header.setBackground(Color.BLACK);
        header.setForeground(Color.WHITE);
        header.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        // Renderizador de celdas para alinear el texto y personalizar bordes
        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer();
        cellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        cellRenderer.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        for (int i = 0; i < tablaProductos.getColumnCount(); i++) {
            tablaProductos.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
        }

        tablaProductos.getColumnModel().getColumn(0).setPreferredWidth(10); // Ajusta el ancho preferido
        tablaProductos.getColumnModel().getColumn(1).setPreferredWidth(100); // Ajusta el ancho preferido

        // Crear un JPanel para el padding y agregar el JScrollPane dentro de él
        JPanel panelConPadding = new JPanel(new BorderLayout());
        panelConPadding.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding de 10px en todos los lados
        JScrollPane scrollPane = new JScrollPane(tablaProductos);
        panelConPadding.add(scrollPane, BorderLayout.CENTER);

        // Agregar el panel con padding al panel principal
        panel.add(panelConPadding, BorderLayout.CENTER);

        add(panel);
    }

    private void cargarProductosEnTabla() {
        String[] columnas = {"ID", "Nombre", "Precio", "Stock"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);
        tablaProductos.setModel(modelo);

        try {
            ProductoDAO productoDAO = new ProductoDAO();
            List<Producto> productos = productoDAO.listarProductos();

            for (Producto producto : productos) {
                Object[] fila = {producto.getId(), producto.getNombre(), producto.getPrecio(), producto.getStock()};
                modelo.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar productos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

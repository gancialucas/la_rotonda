package gui;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class DashboardFrame extends JFrame {
    private JButton btnHistorialVentas, btnAgregarProducto, btnRegistrarVenta, btnCerrarSesion;
    private JButton btnVerListaProductos, btnBuscarProducto;

    public DashboardFrame(int userId) {
        setTitle("Dashboard - La Rotonda");
        setSize(500, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);

        // Título del Dashboard para Administrador
        JLabel lblTitulo = new JLabel("Dashboard | Administrador");
        EstilosGUI.configurarTitulo(lblTitulo); // Aplica el estilo de título
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);

        // Inicializar botones
        btnHistorialVentas = new JButton("Historial de Ventas");
        btnAgregarProducto = new JButton("Agregar Producto");
        btnRegistrarVenta = new JButton("Nueva Venta");
        btnCerrarSesion = new JButton("Cerrar Sesión");
        btnVerListaProductos = new JButton("Ver Lista de Productos");
        btnBuscarProducto = new JButton("Buscar Producto por Nombre");

        // Aplicar estilos
        EstilosGUI.configurarBotonAdmin(btnHistorialVentas);
        EstilosGUI.configurarBotonAdmin(btnAgregarProducto);
        EstilosGUI.configurarBotonAdmin(btnRegistrarVenta);
        EstilosGUI.configurarBotonAdmin(btnVerListaProductos);
        EstilosGUI.configurarBotonAdmin(btnBuscarProducto);
        EstilosGUI.cerrarSesión(btnCerrarSesion);

        // Añadir título y botones al panel principal
        setLayout(new BorderLayout());
        add(lblTitulo, BorderLayout.NORTH); // Añade el título en la parte superior

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(btnVerListaProductos, gbc);

        gbc.gridy = 1;
        panel.add(btnBuscarProducto, gbc);

        gbc.gridy = 2;
        panel.add(btnHistorialVentas, gbc);

        gbc.gridy = 3;
        panel.add(btnAgregarProducto, gbc);

        gbc.gridy = 4;
        panel.add(btnRegistrarVenta, gbc);

        gbc.gridy = 5;
        panel.add(btnCerrarSesion, gbc);

        add(panel, BorderLayout.CENTER);

        // Agregar acciones a los botones
        btnCerrarSesion.addActionListener(e -> cerrarSesion());
        btnAgregarProducto.addActionListener(e -> abrirAgregarProducto());
        btnRegistrarVenta.addActionListener(e -> {
            try {
                abrirRegistrarVenta(userId);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });
        btnVerListaProductos.addActionListener(e -> abrirListaProductos());
        btnBuscarProducto.addActionListener(e -> abrirBuscarProducto());
        btnHistorialVentas.addActionListener(e -> abrirHistorialVentas());
    }

    private void cerrarSesion() {
        new LoginFrame().setVisible(true);
        dispose();
    }

    private void abrirAgregarProducto() {
        new AgregarProductoFrame().setVisible(true);
    }

    private void abrirRegistrarVenta(int userId) throws SQLException {
        new RegistrarVentaFrame(userId).setVisible(true);
    }

    private void abrirListaProductos() {
        new ListaProductosFrame().setVisible(true);
    }

    private void abrirBuscarProducto() {
        new BuscarProductoFrame().setVisible(true);
    }

    private void abrirHistorialVentas() {
        new HistorialVentasFrame().setVisible(true);
    }
}
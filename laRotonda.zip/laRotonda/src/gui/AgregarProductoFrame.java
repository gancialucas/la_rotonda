package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import dao.ProductoDAO;
import gui.EstilosGUI;
import model.Producto;

public class AgregarProductoFrame extends JFrame {
    private JTextField txtNombreProducto, txtPrecioProducto, txtStockProducto;
    private JButton btnGuardar, btnVolver;
    private JLabel lblNombre, lblPrecio, lblStock;

    public AgregarProductoFrame() {
        setTitle("Agregar Producto");
        setSize(400, 300);
        setLocationRelativeTo(null);

        configurarComponentes();
        agregarComponentesAlPanel();
        configurarEventos();
    }

    private void configurarComponentes() {
        lblNombre = new JLabel("Nombre:");
        lblPrecio = new JLabel("Precio:");
        lblStock = new JLabel("Stock:");

        txtNombreProducto = new JTextField();
        txtPrecioProducto = new JTextField();
        txtStockProducto = new JTextField();

        // Configurar estilo de los campos de texto
        EstilosGUI.configurarCampoTexto(txtNombreProducto);
        EstilosGUI.configurarCampoTexto(txtPrecioProducto);
        EstilosGUI.configurarCampoTexto(txtStockProducto);

        btnGuardar = new JButton("Guardar");
        btnVolver = new JButton("Volver");

        // Configurar estilo de los botones
        EstilosGUI.configurarBoton(btnGuardar);
        EstilosGUI.configurarBoton(btnVolver);
    }

    private void agregarComponentesAlPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 5, 10, 5);

        // Agregar componentes al panel
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(lblNombre, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(txtNombreProducto, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(lblPrecio, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(txtPrecioProducto, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(lblStock, gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(txtStockProducto, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(btnGuardar, gbc);
        gbc.gridx = 1;
        gbc.gridy = 4;
        panel.add(btnVolver, gbc);

        // Agregar panel al frame
        add(panel, BorderLayout.CENTER);
    }

    private void configurarEventos() {
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombreProducto.getText();
                int stock;
                double precio;

                // Validación y conversión de campos
                try {
                    stock = Integer.parseInt(txtStockProducto.getText());
                    precio = Double.parseDouble(txtPrecioProducto.getText());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, ingresa valores numéricos válidos para stock y precio.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Creación del producto
                Producto producto = new Producto(0,nombre,precio,stock);

                // Intentar guardar en la base de datos
                ProductoDAO productoDAO = new ProductoDAO();
                try {
                    productoDAO.insertarProducto(producto);
                    JOptionPane.showMessageDialog(null, "Producto registrado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

                    // Limpiar los campos después de registrar el producto
                    txtNombreProducto.setText("");
                    txtStockProducto.setText("");
                    txtPrecioProducto.setText("");
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al registrar el producto: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnVolver.addActionListener(e -> dispose()); // Cierra la ventana actual
    }

}
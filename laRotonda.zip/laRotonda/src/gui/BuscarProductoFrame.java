package gui;

import dao.ProductoDAO;
import model.Producto;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class BuscarProductoFrame extends JFrame {
    private JTextField txtNombre;
    private JTextArea resultado;

    public BuscarProductoFrame() {
        setTitle("Buscar Producto - La Rotonda");
        setSize(450, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());

        JLabel lblNombre = new JLabel("Nombre del Producto:");
        txtNombre = new JTextField(15);
        EstilosGUI.configurarCampoTexto(txtNombre);
        JButton btnBuscar = new JButton("Buscar");
        EstilosGUI.configurarBuscar(btnBuscar);

        btnBuscar.addActionListener(e -> buscarProducto());

        inputPanel.add(lblNombre);
        inputPanel.add(txtNombre);
        inputPanel.add(btnBuscar);

        resultado = new JTextArea();
        resultado.setEditable(false);

        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(resultado), BorderLayout.CENTER);

        add(panel);
    }

    private void buscarProducto() {
        String nombre = txtNombre.getText().trim();

        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese un nombre de producto.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            ProductoDAO productoDAO = new ProductoDAO();
            Producto producto = productoDAO.buscarProducto(nombre);

            if (producto != null) {
                resultado.setText("ID: " + producto.getId() + "\nNombre: " + producto.getNombre() + "\nPrecio: " + producto.getPrecio() + "\nStock: " + producto.getStock());
            } else {
                resultado.setText("Producto no encontrado.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al buscar el producto.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
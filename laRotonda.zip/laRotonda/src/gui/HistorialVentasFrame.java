package gui;

import model.Venta;
import dao.VentaDAO;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class HistorialVentasFrame extends JFrame {
    private JTable tablaVentas;
    private VentaDAO ventaDAO;

    public HistorialVentasFrame() {
        setTitle("Historial de Ventas - La Rotonda");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Configuración del panel principal
        JPanel panel = new JPanel(new BorderLayout());

        // Título
        JLabel lblTitulo = new JLabel("Historial de Ventas");
        EstilosGUI.configurarTitulo(lblTitulo);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(lblTitulo, BorderLayout.NORTH);

        ventaDAO = new VentaDAO();
        try {
            List<Venta> ventas = ventaDAO.obtenerHistorialVentasConEstado();
            Object[][] datos = new Object[ventas.size()][4];
            for (int i = 0; i < ventas.size(); i++) {
                Venta venta = ventas.get(i);
                datos[i][0] = venta.getId();
                datos[i][1] = venta.getNombreUsuario();
                datos[i][2] = venta.getTotal();
                datos[i][3] = venta.getEstado();
            }

            String[] columnas = {"Nº Venta", "Empleado", "Precio Total", "Estado"};
            tablaVentas = new JTable(datos, columnas) {
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (column == 3) { // Columna de estado
                        String estado = getValueAt(row, column).toString();
                        switch (estado) {
                            case "Pago" -> c.setBackground(Color.GREEN);
                            case "Pendiente" -> c.setBackground(Color.YELLOW);
                            case "No abonó" -> c.setBackground(Color.RED);
                            default -> c.setBackground(Color.WHITE);
                        }
                    } else {
                        c.setBackground(Color.WHITE);
                    }
                    return c;
                }
            };

            // Estilos para la tabla
            tablaVentas.setFont(new Font("Arial", Font.PLAIN, 12));
            tablaVentas.setRowHeight(30);
            tablaVentas.setGridColor(Color.BLACK);
            tablaVentas.setShowGrid(true);

            // Configuración del encabezado de la tabla
            JTableHeader header = tablaVentas.getTableHeader();
            header.setFont(new Font("Arial", Font.BOLD, 16));
            header.setBackground(Color.BLACK);
            header.setForeground(Color.WHITE);
            header.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

            // Renderizador de celdas para alinear el texto y personalizar bordes
            DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer();
            cellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
            cellRenderer.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            for (int i = 0; i < tablaVentas.getColumnCount(); i++) {
                tablaVentas.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
            }

            // Ajustar el ancho de la columna ID
            tablaVentas.getColumnModel().getColumn(0).setPreferredWidth(10);

            // Crear un JPanel para el padding y agregar el JScrollPane dentro de él
            JPanel panelConPadding = new JPanel(new BorderLayout());
            panelConPadding.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding de 10px en todos los lados
            JScrollPane scrollPane = new JScrollPane(tablaVentas);
            panelConPadding.add(scrollPane, BorderLayout.CENTER);

            // Agregar el panel con padding al panel principal
            panel.add(panelConPadding, BorderLayout.CENTER);

            add(panel);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar el historial de ventas.");
        }
    }
}
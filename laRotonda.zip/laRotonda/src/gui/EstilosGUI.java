package gui;

import javax.swing.*;
import java.awt.*;

public class EstilosGUI {
    // ESTILO BOTONES
    public static void configurarBoton(JButton boton) {
        boton.setPreferredSize(new Dimension(150, 40));
        boton.setBackground(Color.WHITE);
        boton.setForeground(Color.BLACK);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Borde negro y redondeado
    }

    public static void configurarBotonEmpleado(JButton botonEmpleado) {
        botonEmpleado.setPreferredSize(new Dimension(250, 40));
        botonEmpleado.setBackground(Color.WHITE);
        botonEmpleado.setForeground(Color.BLACK);
        botonEmpleado.setFont(new Font("Arial", Font.BOLD, 14));
        botonEmpleado.setFocusPainted(false);
        botonEmpleado.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Borde negro y redondeado
    }

    public static void configurarBotonAdmin(JButton botonAdmin) {
        botonAdmin.setPreferredSize(new Dimension(250, 40));
        botonAdmin.setBackground(Color.WHITE);
        botonAdmin.setForeground(Color.BLACK);
        botonAdmin.setFont(new Font("Arial", Font.BOLD, 14));
        botonAdmin.setFocusPainted(false);
        botonAdmin.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Borde negro y redondeado
    }

    public static void cerrarSesión(JButton btnCerrarSesion) {
        btnCerrarSesion.setPreferredSize(new Dimension(150, 40));
        btnCerrarSesion.setBackground(Color.PINK);
        btnCerrarSesion.setForeground(Color.WHITE);
        btnCerrarSesion.setFont(new Font("Arial", Font.BOLD, 14));
        btnCerrarSesion.setFocusPainted(false);
        btnCerrarSesion.setBorder(BorderFactory.createLineBorder(Color.RED, 2)); // Borde negro y redondeado
    }

    public static void configurarBuscar(JButton btnBuscar) {
        btnBuscar.setPreferredSize(new Dimension(100, 30));
        btnBuscar.setBackground(Color.WHITE);
        btnBuscar.setForeground(Color.BLACK);
        btnBuscar.setFont(new Font("Arial", Font.BOLD, 14));
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Borde negro y redondeado
    }

    // ESTILO COMBO
    public static void configurarBotonVenta(JButton registrarVentaButton) {
        registrarVentaButton.setPreferredSize(new Dimension(150, 40));
        registrarVentaButton.setBackground(new Color(158, 223, 156));
        registrarVentaButton.setForeground(Color.WHITE);
        registrarVentaButton.setFont(new Font("Arial", Font.BOLD, 14));
        registrarVentaButton.setFocusPainted(false);
        Color borderColor = new Color(98, 130, 93);
        registrarVentaButton.setBorder(BorderFactory.createLineBorder(borderColor, 3));
    }

    // NUEVO - Estilo para botones específicos de "Agregar Producto" en RegistrarVentaFrame
    public static void configurarBotonAgregar(JButton botonAgregar) {
        botonAgregar.setPreferredSize(new Dimension(150, 35));
        botonAgregar.setBackground(new Color(230, 230, 250));
        botonAgregar.setForeground(Color.DARK_GRAY);
        botonAgregar.setFont(new Font("Arial", Font.BOLD, 13));
        botonAgregar.setFocusPainted(false);
        botonAgregar.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
    }

    // ESTILO TEXTO
    public static void configurarCampoTexto(JTextField campo) {
        campo.setPreferredSize(new Dimension(200, 30));
        campo.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        campo.setFont(new Font("Arial", Font.PLAIN, 14));
    }

    public static void configurarTitulo(JLabel lblTitulo) {
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(50, 50, 150));
    }

    public static void configurarTotal(JLabel totalLabel) {
        totalLabel.setFont(new Font("Arial", Font.BOLD, 14));
        totalLabel.setForeground(new Color(0, 102, 0));
    }

    public static void configurarTextArea(JTextArea textArea) {
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        textArea.setBackground(new Color(245, 245, 245));
    }

    // NUEVO - Estilo para ComboBox de productos y estado de venta
    public static void configurarComboBox(JComboBox comboBox) {
        comboBox.setPreferredSize(new Dimension(200, 30));
        comboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        comboBox.setBackground(Color.WHITE);
        comboBox.setForeground(Color.BLACK);
        comboBox.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
    }
}
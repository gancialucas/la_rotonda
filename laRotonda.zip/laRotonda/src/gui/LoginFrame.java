package gui;

import dao.UsuarioDAO;
import model.Usuario;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class LoginFrame extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JButton btnLogin, btnRegister;

    public LoginFrame() {
        setTitle("Inicio de Sesión - La Rotonda");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Config - Panel principal con GridBagLayout
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);

        // Título
        JLabel lblTitulo = new JLabel("La Rotonda - Minimarket");
        EstilosGUI.configurarTitulo(lblTitulo);
        panel.add(lblTitulo, gbc);

        // Label e Input - Usuario
        JLabel lblUsuario = new JLabel("Usuario");
        txtUsuario = new JTextField();
        EstilosGUI.configurarCampoTexto(txtUsuario);

        // Label e Input - Contraseña
        JLabel lblPassword = new JLabel("Contraseña");
        txtPassword = new JPasswordField();
        EstilosGUI.configurarCampoTexto(txtPassword);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(lblUsuario, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(txtUsuario, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(lblPassword, gbc);
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(txtPassword, gbc);

        // Botones Iniciar Sesion - Registrar
        btnLogin = new JButton("Iniciar Sesión");
        btnRegister = new JButton("Registrarse");
        EstilosGUI.configurarBoton(btnLogin);
        EstilosGUI.configurarBoton(btnRegister);

        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(btnLogin, gbc);
        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(btnRegister, gbc);

        add(panel, BorderLayout.CENTER);

        btnLogin.addActionListener(e -> {
            try {
                iniciarSesion(txtUsuario.getText(), new String(txtPassword.getPassword()));
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });
        btnRegister.addActionListener(e -> abrirRegistro());
    }

    private void iniciarSesion(String usuario, String password) throws SQLException {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        if (usuarioDAO.validarCredenciales(usuario, password)) {
            Integer userId = usuarioDAO.getIdUser(usuario);
            if (usuarioDAO.obtenerRol(usuario) == 1) {
                JOptionPane.showMessageDialog(this,"Inicio de sesión, exitoso!", "Iniciar Sesión",1);
                new DashboardFrame(userId).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this,"Inicio de sesión, exitoso!", "Iniciar Sesión",1);
                new EmpleadoFrame(userId).setVisible(true); // Aquí abrirías el frame específico para empleados
            }
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,"Usuario o contraseña incorrectos", "Iniciar Sesión",0);
        }
    }

    private void abrirRegistro() {
        new RegistroFrame().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
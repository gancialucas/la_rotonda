package model;

import java.util.Date;

public class Venta {
    private int id;
    private int idUsuario; // id del usuario que realiza la venta
    private double total; // monto final de la venta $
    private Date created_at;

    public Venta(int id, int idUsuario, double total, Date created_at) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.total = total;
        this.created_at = created_at;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public Date getCreated_at() { return created_at; }
    public void setCreated_at(Date created_at) { this.created_at = created_at; }
}

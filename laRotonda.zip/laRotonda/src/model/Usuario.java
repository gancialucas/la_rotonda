package model;

public class Usuario {
    private int id;
    private String nombre;
    private String contrasena;
    private int rol;

    // Constructor para inicializar un usuario
    public Usuario(int id, String nombre, String contrasena, int rol) {
        this.id = id;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.rol = rol;
    }

    // Métodos Getters y Setters para encapsular los datos
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    public int getRol() { return rol; }
    public void setRol(int rol) { this.rol = rol; }

    // Mostrar info para listar usuario
    public void mostrarInfo(Usuario usuario, int rol) {
        String usuarioRol = rol == 1 ? "Administrador" : "Empleado";
        System.out.println("ID: " + usuario.getId() + " | Usuario: " + usuario.getNombre() + " | Rol: " + usuarioRol);
    }
}